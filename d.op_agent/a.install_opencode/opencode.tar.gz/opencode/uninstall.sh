#!/usr/bin/env bash
# opencode 绿色版 — 卸载脚本
# 行为：
#   1. 删除 $PREFIX/bin/opencode 符号链接
#   2. 删除 $HOME/.config/opencode 符号链接
#   3. 询问是否恢复之前备份的 .bak-*（如果存在）
set -euo pipefail

PREFIX="${PREFIX:-/usr/local}"
SUDO="${SUDO:-}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DST="$PREFIX/bin/opencode"
CONFIG_DST="${XDG_CONFIG_HOME:-$HOME/.config}/opencode"

if [ -t 1 ]; then
  C_RED=$'\e[31m'; C_YEL=$'\e[33m'; C_GRN=$'\e[32m'; C_RST=$'\e[0m'
else
  C_RED=""; C_YEL=""; C_GRN=""; C_RST=""
fi

echo "${C_YEL}==> opencode portable 卸载器${C_RST}"
echo "    BIN_DST    = $BIN_DST"
echo "    CONFIG_DST = $CONFIG_DST"
echo

if [ -n "$SUDO" ] || { [ -L "$BIN_DST" ] && [ ! -w "$(dirname "$BIN_DST")" ]; }; then
  command -v sudo >/dev/null 2>&1 && SUDO="sudo" || true
fi

remove_link() {
  local target="$1"
  local label="$2"
  if [ -L "$target" ]; then
    echo "${C_YEL}    移除符号链接 $target -> $(readlink "$target")${C_RST}"
    $SUDO rm -f "$target"
    echo "${C_GRN}    [OK] $label 已移除${C_RST}"
  elif [ -e "$target" ]; then
    echo "${C_RED}    [SKIP] $target 不是符号链接，未触碰（手动删除）${C_RST}"
  else
    echo "    [SKIP] $target 不存在，跳过"
  fi
}

remove_link "$BIN_DST" "可执行链接"
remove_link "$CONFIG_DST" "配置链接"

# 提示恢复备份
echo
echo "${C_YEL}==> 检查备份${C_RST}"
for bak in "${BIN_DST}.bak-"* "${CONFIG_DST}.bak-"*; do
  [ -e "$bak" ] || continue
  echo "    发现备份: $bak"
done
echo "    如需恢复原配置，请手动将 .bak-* 重命名为 $CONFIG_DST"

echo
echo "${C_GRN}==> 卸载完成${C_RST}"
echo "    如需彻底清理，可执行:  rm -rf $SCRIPT_DIR"